'use client';
import { Card, CardContent } from '@/components/ui/card';
import Navbar from '@/components/Navbar';

export default function TrustPage(){
  function downloadBase64Pdf(filename: string, base64: string){
    const byteChars = atob(base64);
    const byteNumbers = new Array(byteChars.length);
    for (let i = 0; i < byteChars.length; i++) byteNumbers[i] = byteChars.charCodeAt(i);
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
  }

  // Minimal 1-page PDFs (placeholder content)
  const securityOverviewB64 =
    'JVBERi0xLjQKJeLjz9MKMSAwIG9iago8PC9UeXBlIC9DYXRhbG9nL1BhZ2VzIDIgMCBSID4+CmVuZG9iagoyIDAgb2JqCjw8L1R5cGUgL1BhZ2VzL0tpZHMgWzMgMCBSXS9Db3VudCAxID4+CmVuZG9iagozIDAgb2JqCjw8L1R5cGUgL1BhZ2UvUGFyZW50IDIgMCBSL01lZGlhQm94IFswIDAgNTk1IDg0Ml0vQ29udGVudHMgNCAwIFI+PgplbmRvYmoKNCAwIG9iago8PC9MZW5ndGggNjY+PgpzdHJlYW0KQlQKL0YxIDEyIFRmCjEwMCA3OTAgVGQKKE9uZS1QYWdlIFNlY3VyaXR5IE92ZXJ2aWV3KSBUMgowIDc2MCBUZAooQ29tcGxpYW5jZUdQVCAvIFNlY3VyaXR5IE92ZXJ2aWV3IHBsYWNlaG9sZGVyIGZvciBkZW1vcykgVAplbmRzdHJlYW0KZW5kb2JqCnhyZWYKMCA1CjAwMDAwMDAwMDAgNjU1MzUgZgowMDAwMDAwMTA5IDAwMDAwIG4KMDAwMDAwMDE2MCAwMDAwMCBuCjAwMDAwMDAyMzUgMDAwMDAgbgowMDAwMDAwMzYxIDAwMDAwIG4Kc3RhcnR4cmVmCjQyNQolJUVPRgo=';
  const dpaTemplateB64 =
    'JVBERi0xLjQKJeLjz9MKMSAwIG9iago8PC9UeXBlIC9DYXRhbG9nL1BhZ2VzIDIgMCBSID4+CmVuZG9iagoyIDAgb2JqCjw8L1R5cGUgL1BhZ2VzL0tpZHMgWzMgMCBSXS9Db3VudCAxID4+CmVuZG9iagozIDAgb2JqCjw8L1R5cGUgL1BhZ2UvUGFyZW50IDIgMCBSL01lZGlhQm94IFswIDAgNTk1IDg0Ml0vQ29udGVudHMgNCAwIFI+PgplbmRvYmoKNCAwIG9iago8PC9MZW5ndGggNzQ+PgpzdHJlYW0KQlQKL0YxIDEyIFRmCjgwIDc5MCBUZAooRFBBIFRlbXBsYXRlIC0gU2FtcGxlIHBsYWNlaG9sZGVyIGZvciBkZW1vcykgVAowIDc2MCBUZAooQXJ0aWNsZSAxOiBEZWZpbml0aW9ucyAmIFRlcm1zKSBUCmVuZHN0cmVhbQplbmRvYmoKeHJlZgowIDUKMDAwMDAwMDAwMCA2NTUzNSBmCjAwMDAwMDAxMDkgMDAwMDAgbgowMDAwMDAwMTYwIDAwMDAwIG4KMDAwMDAwMDI0MCAwMDAwMCBuCjAwMDAwMDAzNzAgMDAwMDAgbgpzdGFydHhyZWYKNDI1CiUlRU9G';
  const soc2SummaryB64 =
    'JVBERi0xLjQKJeLjz9MKMSAwIG9iago8PC9UeXBlIC9DYXRhbG9nL1BhZ2VzIDIgMCBSID4+CmVuZG9iagoyIDAgb2JqCjw8L1R5cGUgL1BhZ2VzL0tpZHMgWzMgMCBSXS9Db3VudCAxID4+CmVuZG9iagozIDAgb2JqCjw8L1R5cGUgL1BhZ2UvUGFyZW50IDIgMCBSL01lZGlhQm94IFswIDAgNTk1IDg0Ml0vQ29udGVudHMgNCAwIFI+PgplbmRvYmoKNCAwIG9iago8PC9MZW5ndGggODI+PgpzdHJlYW0KQlQKL0YxIDEyIFRmCjgwIDc5MCBUZAooU09DMiBTdW1tYXJ5IC0gU2FtcGxlIHByYWN0aWNlcyBhbmQgaGlnaC1sZXZlbCBjb250cm9scykgVAowIDc2MCBUZAooUmVhZC1vbmx5IGRlbW8gY29udGVudCkgVAplbmRzdHJlYW0KZW5kb2JqCnhyZWYKMCA1CjAwMDAwMDAwMDAgNjU1MzUgZgowMDAwMDAwMTA5IDAwMDAwIG4KMDAwMDAwMDE2MCAwMDAwMCBuCjAwMDAwMDAyNDggMDAwMDAgbgowMDAwMDAwMzk0IDAwMDAwIG4Kc3RhcnR4cmVmCjQyNQolJUVPRg==';

  return (
    <div>
      <Navbar />
      <section className="max-w-6xl mx-auto px-6 py-12">
        <h1 className="text-3xl font-bold mb-4">Security & Trust</h1>
        <p className="text-gray-600 mb-8">Download compliance documents (demo PDFs).</p>
        <Card><CardContent>
          <h2 className="text-xl font-semibold mb-3">Compliance Docs</h2>
          <div className="flex flex-wrap gap-3 text-sm">
            <button className="px-4 py-2 rounded-2xl border" onClick={()=>downloadBase64Pdf('ComplianceGPT-Security-Overview.pdf', securityOverviewB64)}>Download Security Overview (PDF)</button>
            <button className="px-4 py-2 rounded-2xl border" onClick={()=>downloadBase64Pdf('ComplianceGPT-DPA-Template.pdf', dpaTemplateB64)}>Download DPA (Template)</button>
            <button className="px-4 py-2 rounded-2xl border" onClick={()=>downloadBase64Pdf('ComplianceGPT-SOC2-Summary.pdf', soc2SummaryB64)}>Download SOC2 Controls (Summary)</button>
          </div>
        </CardContent></Card>
      </section>
    </div>
  );
}
