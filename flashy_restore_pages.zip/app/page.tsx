'use client';

import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-50 via-white to-white">
      <Navbar />

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute -top-24 -left-24 h-64 w-64 rounded-full bg-indigo-200/40 blur-3xl" />
        <div className="absolute -bottom-24 -right-24 h-72 w-72 rounded-full bg-purple-200/40 blur-3xl" />

        <div className="max-w-6xl mx-auto px-6 pt-20 pb-16 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <span className="inline-flex items-center gap-2 text-xs font-medium px-3 py-1 rounded-full bg-indigo-100 text-indigo-800">
              <span className="inline-block h-1.5 w-1.5 rounded-full bg-indigo-600" /> Enterprise ready
            </span>
            <h1 className="mt-4 text-4xl md:text-6xl font-extrabold tracking-tight">
              Roll out ChatGPT <span className="bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-purple-600">with compliance</span>
            </h1>
            <p className="mt-4 text-lg text-gray-600 max-w-xl">
              Policy enforcement, redaction, approvals, and audit logs—so every prompt and response stays within your rules.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link href="/admin" className="px-5 py-3 rounded-2xl bg-black text-white shadow-md hover:shadow-lg transition">
                Launch Live Demo
              </Link>
              <Link href="/trust" className="px-5 py-3 rounded-2xl border hover:bg-gray-50 transition">
                Security &amp; Trust
              </Link>
              <button
                className="px-5 py-3 rounded-2xl border border-transparent hover:border-gray-300"
                onClick={() => (window as any).openContactSales?.()}
              >
                Contact Sales
              </button>
            </div>
            <p className="mt-3 text-sm text-gray-500">Works with OpenAI, Azure OpenAI, and more.</p>
          </div>

          {/* Hero preview card */}
          <div className="rounded-2xl bg-white shadow-xl ring-1 ring-black/5 p-5">
            <div className="text-sm text-gray-500 mb-2">Admin Preview</div>
            <div className="rounded-xl border p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="font-medium">Policy Decision</div>
                <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">Allowed (Redacted)</span>
              </div>
              <div className="text-xs text-gray-500 mb-1">Prompt (sanitized)</div>
              <pre className="text-sm bg-gray-50 p-3 rounded-lg overflow-auto">
{`"Write a follow-up email to [REDACTED_NAME] about invoice [REDACTED_NUMBER]."`}
              </pre>
              <div className="grid grid-cols-3 gap-2 mt-4">
                <div className="rounded-lg border p-3">
                  <div className="text-xs text-gray-500">PII Redactions</div>
                  <div className="text-lg font-semibold">18</div>
                </div>
                <div className="rounded-lg border p-3">
                  <div className="text-xs text-gray-500">Blocked</div>
                  <div className="text-lg font-semibold">2.4%</div>
                </div>
                <div className="rounded-lg border p-3">
                  <div className="text-xs text-gray-500">Active Users</div>
                  <div className="text-lg font-semibold">1,874</div>
                </div>
              </div>
              <div className="mt-4 text-right">
                <Link href="/admin" className="text-sm underline">See full dashboard →</Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Logos strip */}
      <section className="bg-white border-y">
        <div className="max-w-6xl mx-auto px-6 py-6 flex flex-wrap items-center gap-6 justify-between text-gray-500">
          <span className="text-xs uppercase tracking-wider">Trusted Controls</span>
          <div className="flex-1 grid grid-cols-2 sm:grid-cols-4 gap-4 items-center">
            <div className="rounded-xl border p-3 text-center text-sm">GDPR</div>
            <div className="rounded-xl border p-3 text-center text-sm">PCI</div>
            <div className="rounded-xl border p-3 text-center text-sm">HIPAA</div>
            <div className="rounded-xl border p-3 text-center text-sm">SOC2</div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-white">
        <div className="max-w-6xl mx-auto px-6 py-12 grid md:grid-cols-3 gap-6">
          {['PII Guard','Source Code & Secrets','Human-in-the-Loop'].map((title, idx) => (
            <div key={title} className="rounded-2xl border p-5 hover:shadow-lg transition">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">{title}</h3>
                <span className="text-xs px-2 py-1 rounded-full bg-indigo-50 text-indigo-700">Policy</span>
              </div>
              <p className="mt-2 text-sm text-gray-600">
                {idx===0 && 'Emails, phone numbers, addresses, names—redacted inline with audit entries.'}
                {idx===1 && 'Detect code fragments, repo refs, and credentials before they leave your tenant.'}
                {idx===2 && 'Escalate risky prompts to approvers, then release safely with a full paper trail.'}
              </p>
              <div className="mt-3 text-sm">
                <Link href="/admin" className="underline">View in dashboard →</Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA strip */}
      <section className="max-w-6xl mx-auto px-6 pb-16">
        <div className="rounded-2xl bg-gradient-to-r from-black to-gray-800 text-white p-8 md:p-10 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="text-xl font-semibold">Ship ChatGPT with confidence</div>
            <div className="text-sm text-gray-300">Zero-retention mode. Region routing. Audit exports.</div>
          </div>
          <div className="flex gap-3">
            <Link href="/trust" className="px-4 py-2 rounded-2xl bg-white text-black">Security &amp; Trust</Link>
            <Link href="/admin" className="px-4 py-2 rounded-2xl border border-white">Launch Demo</Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
